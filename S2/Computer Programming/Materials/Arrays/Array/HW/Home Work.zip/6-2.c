#include<stdio.h>
/*NAME : S.ABHISHEK
ROLL NUMBER : AM.EN.U4CSE19147
BATCH : S2-CSE-B*/
int main()
{
    int arr[10];
    char arr1[10];
    float arr2[10];
    double arr3[10];
    printf("The size of the 10 elements in integer array is %d.\n",sizeof(arr));
    printf("The size of the 10 elements in character array is %d.\n",sizeof(arr1));
    printf("The size of the 10 elements in Float array is %d.\n",sizeof(arr2));
    printf("The size of the 10 elements in Double array is %d.",sizeof(arr3));
    return 0;
}
