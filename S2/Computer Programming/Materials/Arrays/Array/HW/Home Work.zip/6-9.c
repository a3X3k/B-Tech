#include<stdio.h>
/*NAME : S.ABHISHEK
ROLL NUMBER : AM.EN.U4CSE19147
BATCH : S2-CSE-B*/
int main()
{
    int arr[]={1,2,3,4,5};
    int *a;
    a=arr;
    printf("%d",*(a+1));
    return 0;
}
