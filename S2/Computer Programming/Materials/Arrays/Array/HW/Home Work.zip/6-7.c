#include<stdio.h>
/*NAME : S.ABHISHEK
ROLL NUMBER : AM.EN.U4CSE19147
BATCH : S2-CSE-B*/
int main()
{
    int x=10,*y=&x,**z=&y;
    printf("The value of x=%d ,y=%d ,z=%d.",x,*y,**z);
    return 0;
}
