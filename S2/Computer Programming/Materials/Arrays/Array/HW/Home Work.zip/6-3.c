#include<stdio.h>
/*NAME : S.ABHISHEK
ROLL NUMBER : AM.EN.U4CSE19147
BATCH : S2-CSE-B*/
int main()
{
    int arr[]={1,2,3,4,5,6,7,8,9,0};
    printf("The number of elements in the array is %d.",sizeof(arr)/sizeof(arr[0]));
    return 0;
}
